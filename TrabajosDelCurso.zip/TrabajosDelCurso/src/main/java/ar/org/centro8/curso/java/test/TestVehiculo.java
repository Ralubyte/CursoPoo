package ar.org.centro8.curso.java.test;

import ar.org.centro8.curso.java.entities.Vehiculo;
import ar.org.centro8.curso.java.entities.autoClasico;
import ar.org.centro8.curso.java.entities.autoNuevo;

public class TestVehiculo {
    
    public static void main(String[] args) {
        
        /**
         * autoClasico(color string,marca string,modelo string ,precio float)
         * 
         * autoNuevo(color string,marca string, modelo string, precio float, radio string);
         */
        //  -- Autos clasico -- 
        autoClasico v1 = new autoClasico("Rojo","Renault","zoe",15000);
        autoClasico v2 = new autoClasico("Negro","Fiat","Cronos",11000);
        
        v1.agregarRadio("Alpine");
        v2.agregarRadio("Pionner");
        System.out.println(v1.toString()+"\n");
        System.out.println(v2.toString());
       
        //-- Autos Nuevos --
     /* autoNuevo a1 = new autoNuevo("Blanco","BMW","i8",30000,"Pionner");
      a1.cambiarRadio("Alpine");
      System.out.println(a1.toString());
      */
    }
}
