package ar.org.centro8.curso.java.entities;

public class Radio {
    
    private String marca;

    public Radio(String marca) {
        this.marca = marca;
    }
    
    public String getMarca() {
        return marca;
    }
    
    @Override
    public String toString() {
        return "Radio" + "\nMarca= " + marca;
    }    

}
