package ar.org.centro8.curso.java.entities;

public class Vehiculo {
    
    private String color;
    private String marca;
    private String modelo;
    private float precio;

    public Vehiculo() {
    }
    
    public Vehiculo(String color, String marca, String modelo, float precio) {
        this.color = color;
        this.marca = marca;
        this.modelo = modelo;
        this.precio = precio;
    }
    
    @Override
    public String toString() {
        return "Vehiculo" + "\nColor= " + color + "\nMarca=" + marca + "\nModelo= " + modelo + "\nPrecio= " + precio;
    }

    public float getPrecio() {
        return precio;
    }

    public void setPrecio(float precio) {
        this.precio = precio;
    }

    public String getColor() {
        return color;
    }

    public String getMarca() {
        return marca;
    }

    public String getModelo() {
        return modelo;
    }

}
