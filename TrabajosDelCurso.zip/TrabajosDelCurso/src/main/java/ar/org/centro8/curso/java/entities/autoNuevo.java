package ar.org.centro8.curso.java.entities;


public class autoNuevo extends Vehiculo {
    
    private Radio radio;

    public autoNuevo(String color, String marca, String modelo, float precio,Radio radio) {
        super(color, marca, modelo, precio);
        this.radio = radio;
    }
    
    /**
     * Y se puede cambiar
     */
    
    public void cambiarRadio(String marca) {
        radio = new Radio(marca);
    }
    
     /**
     * public void radio(){
        String marca;
        Scanner entrada = new Scanner(System.in);
        System.out.println("Ingrese la marca marca de la radio que desea cambiar");
        marca=entrada.next();
        radio = new Radio(marca);
        System.out.println("Se cambio: "+radio.toString());
    }
     */

    @Override
    public String toString() {
        return "Auto Nuevo: " + super.toString() + radio;
    }
    
}
