package ar.org.centro8.curso.java.entities;

public class autoClasico extends Vehiculo {
    
    private Radio radio;
    /**
     * Un Auto Clásico se puede fabricar sin radio
     */
    
    public autoClasico(String color, String marca, String modelo, float precio) {
        super(color, marca, modelo, precio);
    }

    /**
     * después se puede agregar 1 radio.
     */
    
    public void agregarRadio(String marca){
        radio = new Radio(marca);
    }

    /**
     * public void radio(){
        String marca;
        Scanner entrada = new Scanner(System.in);
        System.out.println("Ingrese la marca marca de la radio que desea agregar");
        marca=entrada.next();
        radio = new Radio(marca);
        System.out.println("Se agrego: "+radio.toString());
    }
     */
    
    @Override
    public String toString() {
        return "Auto Clasico: " + super.toString() + radio;
    }
    
    
}
